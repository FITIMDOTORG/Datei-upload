<?php header("Location: https://upload.fitim.org/abfrage.php"); ?>
